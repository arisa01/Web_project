<?php
	session_start();
	
	$conn = mysqli_connect("localhost","root","","webdevproject");
	if(isset($_POST['sub'])){
		session_start();
		  $name =  mysql_real_escape_string($_POST['name']);
		  $loc = mysql_real_escape_string ($_POST['location']);
		  $email =  mysql_real_escape_string ($_POST['email']);
		  $pass =  mysql_real_escape_string ($_POST['pass']);
		  $pass2 =  mysql_real_escape_string ($_POST['passcon']);
		  $description =  mysql_real_escape_string ($_POST['description']);
		 
		if ($pass == $pass2){
			
			$pass = md5($pass);
			$sql = "INSERT INTO employer(name, location, email, password, description) VALUES('$name','$loc','$email','$pass','$description')";
			mysqli_query($conn,$sql);
			$_SESSION['message']="You are now logged in";
			$_SESSION['username']=$name;
			
			}else{
				$_SESSION['message']="The two passwords do not match";		
		}
		
	}
?>

	  
<?php
	  $name = filter_input(INPUT_POST,'name');
	  $gender = filter_input(INPUT_POST, 'gender');
	  $email = filter_input(INPUT_POST, 'email');
	  $university = filter_input(INPUT_POST, 'uni');
	  $course = filter_input(INPUT_POST, 'course');
	  $certifications = filter_input(INPUT_POST, 'certs');
	  $password = filter_input(INPUT_POST, 'pass');
	   
	  if (!empty($name) && !empty($gender) && !empty($email) && !empty($university) && 
			!empty($course) && !empty($certifications) && !empty(password)){
		    $servername = "localhost";
			$username = "root";
			$password = "";
			$database = "webdevproject";
			
			global $conn;
	$conn = new mysqli($servername, $username, $password,$database);
	// Check connection
          $password = md5 ($password);
	if (mysqli_connect_error()) {
	    die('Connection Error ('  . mysqli_connect_errno() .')'
		.mysqli_connect_error());
	} else{
			$sql = "INSERT INTO student(id, name, gender, email, university, course, certifications, password)
					VALUES ('$name','$gender','$email','$university','$course','$certifications','$password')";
					
				if ($conn->query($sql)){
							echo "new account created";
				} else{
					echo "Error: ".$sql."<br>".$conn->error;
					$conn->close();
				}
	}
}else{
          echo "ensure that all fields are entered";
      }
	  






?>